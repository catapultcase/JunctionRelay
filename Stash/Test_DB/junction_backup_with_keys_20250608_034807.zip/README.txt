Junction Relay Backup Package
============================

This backup contains:
- junction_backup.db: Your Junction Relay database
- keys/: Encryption keys for decrypting secrets

To restore:
1. Upload this entire ZIP file using the 'Upload Database File' button
2. The database and keys will be automatically restored
3. Restart the application to apply changes

Backup created: 2025-06-08 03:48:06 UTC
Junction Relay Version: 0.8.0.3
